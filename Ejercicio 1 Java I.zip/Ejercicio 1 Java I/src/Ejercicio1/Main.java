package Ejercicio1;

public class Main {
    public static void main(String[] args) {
        // Números enteros
        byte number 1=1;
        short numer 2=2;
        int number 3=3;
        long number 4=4;

        //Puntos flotantes
        float decimal1=4,9f;
        double decimal2=9,99;

        //Carácter
        char character 1='a';

        //Booleanos

        boolean verdadero=true;
        boolean falso=false;

        //Cadenas de texto

        String nombre="Paco";

        //Tipos envoltorio
        Integer numero=null;
        Long numero 2= 2L;

    }
}
